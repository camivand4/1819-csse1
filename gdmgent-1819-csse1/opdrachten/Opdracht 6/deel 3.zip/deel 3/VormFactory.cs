namespace deel_3
{
    public class VormFactory
    {
        // aanmaken van instantie type cirkel 👌
        public IVorm GetVorm(string typeVorm)
        {
            if(typeVorm == null)
            {
                return null;
            }
            else if (typeVorm.Equals("Cirkel") )
            //else if (typeVorm == "Cirkel" )
            {
                return new Cirkel();
            }

            return null;
        }
    }
}