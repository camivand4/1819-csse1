﻿using System;

namespace deel_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("hello dutsjes");

            VormFactory vormFactory = new VormFactory();
            IVorm vormA = vormFactory.GetVorm("Cirkel");

            vormA.Teken();
        }
    }
}
