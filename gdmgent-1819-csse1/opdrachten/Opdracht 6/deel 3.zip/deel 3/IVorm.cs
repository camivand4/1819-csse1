using System;

namespace deel_3 {
    public interface IVorm
    {
        void Teken();
        //iedereen da mij nodig heeft gaat void teken moeten runnen, trekt niet implementatie aan 👌
    }
}