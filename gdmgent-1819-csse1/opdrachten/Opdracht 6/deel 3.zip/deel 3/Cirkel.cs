using System;

namespace deel_3 {
    public class Cirkel : IVorm
    {
        public void Teken()
        {
            Console.WriteLine("Cirkel");
            // throw new System.NotImplementedException();
            //velden 
        }
    }
}